﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float speed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        float verticalInput = Input.GetAxis("Vertical");
        float ClampY = Mathf.Clamp(transform.position.y+verticalInput * speed * Time.deltaTime, -4f, 4f);
        transform.position =  new Vector3(transform.position.x , ClampY , transform.position.z);

    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Red")
        {
            SceneManager.LoadScene(1);
            Debug.Log("R");
        }
        else if (other.gameObject.tag == "Brown")
        {
            int minus = -1;
            Debug.Log("B");
            Destroy(other.gameObject);            
            GameManager.thisManager.UpdateScore(minus);
        }
        else if (other.gameObject.tag == "Green")
        {
            int add = 1;
            Destroy(other.gameObject);           
            GameManager.thisManager.UpdateScore(add);
            Debug.Log("G");

        }
    }
}
